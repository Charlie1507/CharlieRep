package com.silva.app.p4cams;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Gen1P4CamsApplicationTests {

	@Test
	void contextLoads() {
	}

}
