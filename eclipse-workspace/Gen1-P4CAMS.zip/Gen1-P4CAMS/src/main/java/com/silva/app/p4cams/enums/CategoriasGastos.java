package com.silva.app.p4cams.enums;

public enum CategoriasGastos 
{
	Alimentos,
	Transporte,
	Recuerdos,
	Museos,
	Parques

}
