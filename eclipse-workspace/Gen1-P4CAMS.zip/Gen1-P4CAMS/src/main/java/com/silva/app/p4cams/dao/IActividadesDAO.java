package com.silva.app.p4cams.dao;

import org.springframework.data.repository.CrudRepository;

import com.silva.app.p4cams.models.Actividad;

public interface IActividadesDAO extends CrudRepository<Actividad, Long>
{

}
