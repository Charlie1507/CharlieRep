package com.silva.app.p4cams.dao;

import org.springframework.data.repository.CrudRepository;

import com.silva.app.p4cams.models.Gasto;

public interface IGastosDAO extends CrudRepository<Gasto, Long>
{

}
