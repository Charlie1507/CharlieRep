package com.silva.app.p4cams;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Gen1P4CamsApplication {

	public static void main(String[] args) {
		SpringApplication.run(Gen1P4CamsApplication.class, args);
	}

}
