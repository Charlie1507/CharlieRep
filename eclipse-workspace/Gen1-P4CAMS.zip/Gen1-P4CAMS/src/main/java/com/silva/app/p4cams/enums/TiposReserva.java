package com.silva.app.p4cams.enums;

public enum TiposReserva 
{
	Hotel,
	Vuelo,
	Actividad,
	Transporte
}
