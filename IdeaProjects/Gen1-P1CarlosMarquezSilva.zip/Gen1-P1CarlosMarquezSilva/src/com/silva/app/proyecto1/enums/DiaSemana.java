package com.silva.app.proyecto1.enums;

public enum DiaSemana
{
    LUNES,
    MARTES,
    MIERCOLES,
    JUEVES,
    VIERNES,
    SABADO,
    DOMINGO
}
