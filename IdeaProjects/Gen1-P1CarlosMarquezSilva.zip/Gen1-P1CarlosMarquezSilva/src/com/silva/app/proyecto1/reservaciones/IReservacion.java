package com.silva.app.proyecto1.reservaciones;

public interface IReservacion <T>
{
    public void reservarHabitacion (T habitacion);
}
