import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class C1
{
    public static void main(String[] args)
    {
        int opc=0;
        int opcs=0;
        int sublong;
        String nuevac = null;
        Scanner s = new Scanner(System.in);
        List<List<String>> categoria = new ArrayList<>();
        List<String> categorianom = new ArrayList<>();
        List<String> vinos = new ArrayList<>();
        List<String> carnes = new ArrayList<>();
        List<String> blancos = new ArrayList<>();
        categorianom.add("Vinos y licores");
        categorianom.add("Carnes frias");
        categorianom.add("Blancos");
        categoria.add(vinos);
        categoria.add(carnes);
        categoria.add(blancos);
        carnes.add("Salchicha");
        carnes.add("Jamon");
        carnes.add("Queso");
        carnes.add("Salami");
        int lon= categorianom.size();

        System.out.println("Menu");
        System.out.println("");
        System.out.println("1) Mostrar Categorias");
        System.out.println("2) Mostrar Productos por categoria");
        System.out.println("3) Agregar Categoria");
        System.out.println("4) Agregar Producto a una categoria");
        System.out.println("5) Salir");

        while(opc!=5)
        {
            System.out.println("Elige la opcion deseada: ");
            opc = s.nextInt();
            switch (opc)
            {
                case 1:
                    for (int i = 0; i < lon; i++)
                    {
                        System.out.println(categorianom.get(i));
                    }
                    System.out.println("Para volver al menu presione 1");
                    opcs=s.nextInt();
                    while(opcs!=1) {
                        if (opcs != 1) {
                            System.out.println("Seleccione una opcion valida");
                        } else {
                            opc = 0;

                        }
                    }
                    opcs = 0;
                    break;
                case 2:
                    while(opcs!=1)
                    {
                        for (int i = 0; i < lon; i++)
                        {
                            System.out.println((i + 1) + ") " + categorianom.get(i));
                        }
                        System.out.println("Selecciona la categoria deseada:");
                        opcs = s.nextInt();
                        if (opcs < 0 || opcs > lon)
                        {
                            System.out.println("Seleccione una opcion valida");
                        }
                        else
                        {
                            sublong=categoria.get(opcs).size();
                            for (int j = 0; j <sublong; j++)
                            {
                                categoria.get(opcs).get(j);
                            }
                            opcs=0;
                        }
                    }
                    System.out.println("Para salir presione 1");
                    opcs=s.nextInt();
                    while(opcs!=1) {
                        if (opcs != 1) {
                            System.out.println("Seleccione una opcion valida");
                        } else {
                            opc = 0;
                        }
                    }
                    opcs=0;

                    break;
                case 3:
                    System.out.println("Digite el nombre de la nueva categoria");
                    nuevac=s.next();
                    categorianom.add(nuevac);
                    System.out.println("Para salir presione 1");
                    opcs=s.nextInt();
                    while(opcs!=1) {
                        if (opcs != 1) {
                            System.out.println("Seleccione una opcion valida");
                        } else {
                            opc = 0;
                        }
                    }
                    nuevac=null;
                    opcs=0;
                    opc=0;
                    break;
                case 4:
                    while(opcs!=1)
                    {
                        for (int i = 0; i < lon; i++)
                        {
                            System.out.println((i + 1) + ") " + categorianom.get(i));
                        }
                        System.out.println("Selecciona la categoria donde desea agregar el elemento:");
                        opcs = s.nextInt();
                        if (opcs < 0 || opcs > lon)
                        {
                            System.out.println("Seleccione una opcion valida");
                        }
                        else
                        {
                            sublong=categoria.get(opcs).size();
                            for (int j = 0; j <sublong; j++)
                            {
                                categoria.get(opcs).get(j);
                            }
                            opcs=0;
                        }
                    }
                    opc=0;
                    break;
                case 5:
                    opc=5;
                    break;
                default:
                    System.out.println("selecciona una respuesta correcta");
                    break;
            }
        }


    }
}
