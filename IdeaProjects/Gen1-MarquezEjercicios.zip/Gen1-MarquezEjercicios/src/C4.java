import java.util.Scanner;

public class C4
{
    public static void main(String[] args)
    {
        double altura;
        double diagonalMenor;
        double diagonalMayor;

        Scanner s = new Scanner(System.in);

        System.out.println("Cual es la altura del prisma: ");
        altura = s.nextDouble();
        System.out.println("Cual es la diagonal menor del prisma: ");
        diagonalMenor = s.nextDouble();
        System.out.println("Cual es la diagonal mayor del prisma: ");
        diagonalMayor = s.nextDouble();

        System.out.println("El area del prisma es: " + (((diagonalMenor*diagonalMayor)/2)*altura));
    }
}
