package com.silva.app.p3cams.repositories;

import com.silva.app.p3cams.models.Propiedad;

public interface IPropiedadRepository extends IRepository<Propiedad>
{
}
