package com.silva.app.p3cams.models.enums;

public enum TipoPropiedad
{
    CASA,
    DEPARTAMENTO,
    TERRENO
}
