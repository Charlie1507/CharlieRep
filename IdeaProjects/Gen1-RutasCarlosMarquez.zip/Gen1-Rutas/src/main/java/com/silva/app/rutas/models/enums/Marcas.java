package com.silva.app.rutas.models.enums;

public enum Marcas
{
    VOLVO,
    ALLIANCE,
    FORD,
    MERCEDES_BENZ,
    DINA
}
