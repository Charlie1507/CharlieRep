import { Component } from '@angular/core';

@Component({
  selector: 'app-edicion',
  standalone: true,
  imports: [],
  templateUrl: './edicion.component.html',
  styleUrl: './edicion.component.css'
})
export class EdicionComponent {

}
