import { Component } from '@angular/core';

@Component({
  selector: 'app-alta-usuario',
  standalone: true,
  imports: [],
  templateUrl: './alta-usuario.component.html',
  styleUrl: './alta-usuario.component.css'
})
export class AltaUsuarioComponent {

}
